# KeePassX Puppet Module for Boxen

Install [KeePassX](http://www.keepassx.org), cross platform password manager.

## Usage

```puppet
include keepassx
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
