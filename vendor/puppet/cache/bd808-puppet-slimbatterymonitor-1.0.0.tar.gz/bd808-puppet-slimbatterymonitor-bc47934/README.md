# SlimBatteryMonitor Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-slimbatterymonitor.png?branch=master)](https://travis-ci.org/boxen/puppet-slimbatterymonitor)

## Usage

```puppet
include slimbatterymonitor
```

## Required Puppet Modules

* `boxen`
