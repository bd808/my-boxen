require 'spec_helper'

describe 'osx::firewall::config' do
  it 'should be tested'
end
