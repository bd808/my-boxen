# Monolingual Puppet Module for Boxen

[![Build Status](https://travis-ci.org/bd808/puppet-monolingual.png?branch=master)](https://travis-ci.org/bd808/puppet-monolingual)

## Usage

```puppet
include monolingual
```

## Required Puppet Modules

* `boxen`
