# GeekTool Puppet Module for Boxen

[![Build Status](https://travis-ci.org/bd808/puppet-geektool.png?branch=master)](https://travis-ci.org/bd808/puppet-geektool)

Install [GeekTool](http://projects.tynsoe.org/en/geektool/) on your Mac.

## Usage

```puppet
include geektool
```

## Required Puppet Modules

* `boxen`
