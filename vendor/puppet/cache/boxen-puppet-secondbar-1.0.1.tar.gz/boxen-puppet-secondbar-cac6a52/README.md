# SecondBar Puppet Module for Boxen [![Build Status](https://travis-ci.org/boxen/puppet-secondbar.png)](https://travis-ci.org/boxen/puppet-secondbar)

Install [SecondBar](http://blog.boastr.net/?page_id=79), a tool which allows you to have more than one menubar in Mac OS X.

## Usage

```puppet
include secondbar
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
